## React carousel component

Steps to install :

1.Download the folder/git clone the repo

2.cd root directory of the folder

3.npm install

4.npm start

Access localhost:3000 on your browser
